import { useState } from 'react'
 
 
import Todo from './component/Todo'
import "./App.css"
import Header from './component/Header'

function App() {
   

  return (
    <>
      <div className='App'>
        <Header />
        <Todo />
      </div>
       
    </>
  )
}

export default App
