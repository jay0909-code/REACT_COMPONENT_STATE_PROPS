import styles from "./form.module.css"
import { useState } from "react"
export default function Form({ todos, setTodos }) {
    const [todo, setTodo] = useState({
        name:"",
        done:false
    })
    const handleSubmit = (e) => {
        e.preventDefault()
        setTodos([
            ...todos,
            todo
        ])
        setTodo({
            name:"",
            done:false
        })
    }
    return (

        <form className={styles.todoform} action="" onSubmit={handleSubmit}>
            <div className={styles.main}>
            <input className={styles.moderninput} type="text" onChange={(e) => setTodo({name:e.target.value,done:false})} value={todo.name} placeholder="Enter Todo Item..." />
            <input className={styles.modernbutton} type="submit" value="Add" />
        </div>
        </form >
       
    )
}