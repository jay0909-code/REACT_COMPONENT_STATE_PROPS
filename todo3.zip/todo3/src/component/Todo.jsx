import { useState,React } from "react"
import Form from "./Form"
import Todolist from "./Todolist"
import Footer from "./Footer"
 

function Todo(){
    
    const [todos,setTodos] = useState([])
    

    
    const completeTodo = todos.filter((todo)=>{
        return todo.done
    }).length

    const totalTodos = todos.length

     
    return(
        <div>
            {/* <Form /> */}
            <Form todos={todos} setTodos={setTodos}   />
            
             <Todolist todos={todos} setTodos={setTodos} />
              <Footer completeTodo = {completeTodo} totalTodos = {totalTodos} />
        </div>
        
    )
}

export default Todo