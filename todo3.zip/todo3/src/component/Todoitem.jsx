import styles from "./todolist.module.css"
export default function Todoitem({index,i,todos,setTodos}){
    const onDelete = (id)=>{
        
        
        const dt = todos.filter((i,index)=>{
            return  index != id
        })
        setTodos(dt)
        
         
    }

    // const handleClick = (name)=>{
    //     const newArray = todos.map((todo)=>{
    //         if(todo.name === name){
    //             return {...todo,done:!todo.done}
    //         }
    //         return todo
    //     })
    //     setTodos(newArray)
    //     console.log(todos);
        
    // }

    const handleClick = (name)=>{
        console.log("Item clicked",name);
        const newArray = todos.map((todo)=>{
            if(todo.name === name){
                console.log("Toggling done for",todo);
                return {...todo,done:!todo.done}
            }
            return todo
        })
        console.log("Updated todos",newArray);
        setTodos(newArray)
        
    }

const classname = i.done?styles.completed : ""
    return (
        <tr>
                            <td className={styles.sublist}>{index+1}</td>
                            <td className={ classname}>{i.name}</td>
                            <td>
                                <button  onClick={()=>handleClick(i.name)}>Edit</button>
                                <button   onClick={()=>onDelete(index)}>Delete</button>
                            </td>
                         </tr>
    )
}