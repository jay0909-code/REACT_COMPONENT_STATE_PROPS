import Todoitem from "./Todoitem"
import styles from "./todolist.module.css"
export default function Todolist({todos,setTodos}){
    const sortedTodos = todos
    .slice()
    .sort((a,b)=>Number(a.done) - Number(b.done))
    return (
        <table className={styles.list}>
                <tr>
                    <th className={styles.sublist}>Id</th>
                    <th className={styles.sublist}>Name</th>
                    <th className={styles.sublist}>Action</th>
                </tr>
                {
                    sortedTodos.map((i,index)=>{
                         return (<Todoitem key={i} index={index} i={i} todos={todos} setTodos={setTodos} />)
                    })
                }
        </table>
    )
}